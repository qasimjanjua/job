First of all install dependencies: <br />
composer install

<br />

Copy .env.example to .env and setup database accordingly.

<br />
Migrate and run db seeder.
<br />

Test the system (Feature/ProductTest): 
php artisan test